import socketio
import random
import time

sio = socketio.Client()

@sio.event
def connect():
    print('Connection Established')

@sio.event
def my_message(data):
    time.sleep(2)
    print('Received Message from Server', data)
    random_num = random.randint(0,1000)
    sio.emit('my_message', {'random_num': random_num})

@sio.event
def disconnect():
    print('disconnected from server')

sio.connect('http://localhost:5000')
random_num = random.randint(0,1000)
sio.emit('my_message', {'random_num': random_num})
sio.wait()