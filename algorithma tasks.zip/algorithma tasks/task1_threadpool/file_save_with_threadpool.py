import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import random

FILES = ['random_file_1',
   'random_file_2',
   'random_file_3',
   'random_file_4',
   'random_file_5']
RANDOM_NUM_START = 0
RANDOM_NUM_END = 200
DIRECTORY_NAME = "pool files"

def create_file(folderpath, file_name):
    with open(os.path.join(folderpath,file_name+".txt"), "w") as file:
        # Writing random integer to a file
        file.write(str(random.randrange(RANDOM_NUM_START,RANDOM_NUM_END)))

# create a thread pool with 5 worker threads
with ThreadPoolExecutor(max_workers=5) as executor:

    # creating a new directory for saving generated files
    folderpath = os.path.join(os.getcwd(), DIRECTORY_NAME)
    if not os.path.exists(folderpath):
        os.makedirs(folderpath)
    future_obj = {executor.submit(create_file, folderpath, FILES[index]): FILES[index] \
        for index in random.sample(range(0, len(FILES)), len(FILES))}
    for future in as_completed(future_obj):
        filename = future_obj[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (filename, exc))
        else:
            print('%s generated Successfully inside %s'  %(filename, DIRECTORY_NAME))